let increment = 0;

function setup() {
  createCanvas(600, 600);
  background("Black");
  rectMode(CENTER);
  angleMode(DEGREES);

  angle = 0;
  angleVel = 60.5; // ***
}

function draw() {
  x = increment * 0.1;
  y = 0;
  w = increment;
  h = 30;
  angle = angleVel * increment; //angle += angleVel;

  if (mouseIsPressed) {
    increment++;

    push();
    blendMode(ADD);
    translate(100, 500);
    rotate(angle);
    //stroke("OrangeRed");
    stroke(150, 50, 5);
    noFill();
    rect(x, y, w, h);
    pop();

    push();
    blendMode(ADD);
    translate(300, 300);
    rotate(angle * 3.5);
    stroke(255, 50, 5);
    //stroke("orange");
    noFill();
    rect(x, y, w, h);
    pop();

    push();
    blendMode(ADD);
    translate(475, 500);
    rotate(angle * 1.5);
    stroke(150, 50, 5);
    //stroke("FireBrick");
    noFill();
    rect(x, y, w, h);
    pop();

    push();
    blendMode(ADD);
    translate(100, 100);
    rotate(angle * 1.5);
    stroke(150, 50, 5);
    //stroke("FireBrick");
    noFill();
    rect(x, y, w, h);
    pop();

    push();
    blendMode(ADD);
    translate(475, 100);
    rotate(angle * 1.5);
    stroke(150, 50, 5);
    //stroke("FireBrick");
    noFill();
    rect(x, y, w, h);
    pop();
  }
}
